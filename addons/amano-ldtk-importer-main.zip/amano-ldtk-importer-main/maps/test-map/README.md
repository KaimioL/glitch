The following files are used here:

 - "Cavernas", a free texture pack by Adam Saltsman (https://adamatomic.itch.io/cavernas)
 - "SunnyLand", a texture pack by Ansimuz (https://ansimuz.itch.io/sunny-land-pixel-game-art)
 - "Inca" by Kronbits (https://kronbits.itch.io/inca-game-assets)
 - "Nuclear Blaze" by Sébastien Benard (https://deepnight.net), under Creative Common Attribution-ShareAlike 4.0 licence (https://creativecommons.org/licenses/by-sa/4.0/)
